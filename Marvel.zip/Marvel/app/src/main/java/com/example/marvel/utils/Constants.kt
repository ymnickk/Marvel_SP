package com.example.marvel.utils

class Constants {

    object Screens{
        const val MAIN_SCREEN = "main_screen"
        const val HERO_SCREEN = "hero_screen"
    }
}