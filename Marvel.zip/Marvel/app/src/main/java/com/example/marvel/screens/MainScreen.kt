@file:OptIn(ExperimentalFoundationApi::class)

package com.example.marvel.screens

import androidx.compose.animation.core.animateSizeAsState
import androidx.compose.animation.defaultDecayAnimationSpec
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.SnapFlingBehavior
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardColors
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.compose.rememberImagePainter

@Composable
fun MainScreen() {
    Mian()
}
@Composable
fun Mian() {

    val lazyListState = rememberLazyListState()
    val snapBehavior = rememberSnapFlingBehavior(lazyListState = lazyListState)

    Surface(color = Color.Gray, modifier = Modifier.fillMaxSize()) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(1.dp)) {
            Image(
                painter = rememberImagePainter("https://effectiveband.notion.site/image/https%3A%2F%2Fprod-files-secure.s3.us-west-2.amazonaws.com%2Fab5510e9-0d2f-404e-9f55-374c7a36d382%2F014c0cb6-64d9-45bd-a3e1-a3cf608257e3%2FUntitled.png?table=block&id=47c3f47d-d604-431d-aa05-6728c63df83d&spaceId=ab5510e9-0d2f-404e-9f55-374c7a36d382&width=2000&userId=&cache=v2"),
                contentDescription = null,
                modifier = Modifier.size(170.dp)
            )

            Text(
                text = "Choose your hero",
                fontSize = 37.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            val heroes = listOf(
                Hero("Iron Man", "https://gas-kvas.com/grafic/uploads/posts/2023-09/1695883903_gas-kvas-com-p-kartinki-zheleznogo-cheloveka-2.jpg", "Tony Stark is a billionaire, playboy, and philanthropist who dons an advanced armored suit to become Iron Man."),
                Hero("Captain America", "https://img.championat.com/s/1350x900/news/big/f/s/kris-evans-vnov-pogovoril-pro-vozvraschenie-k-roli-kapitana-amerika_16551155481664123558.jpg", "Steve Rogers is a World War II soldier who is enhanced with super-soldier serum."),
                Hero("Thor", "https://kartinki.pics/uploads/posts/2022-12/1670419854_20-kartinkin-net-p-tor-kartinki-instagram-22.jpg", "The God of Thunder, Thor is a powerful Asgardian who wields the mighty hammer Mjolnir."),
                // ... (добавить других героев)
            )

            LazyRow(
                modifier = animateSizeAsState(targetValue = ),
                state = lazyListState,
                flingBehavior = snapBehavior
            ) {
                items(heroes.size) { index ->
                    val hero = heroes[index]
                    HerItem(hero = hero)
                }
            }
        }
    }
}

data class Hero(
    val name: String,
    val imageUrl: String,
    val description: String
)


@Composable
fun HerItem(hero: Hero) {
    Card(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(15.dp),
    ) {
        AsyncImage(
            model = hero.imageUrl,
            alignment = Alignment.Center,
            contentDescription = hero.name,
            modifier = Modifier
                .width(370.dp)
                .height(600.dp),
            contentScale = ContentScale.FillHeight
        )

    }
}