package com.example.marvel.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.marvel.screens.HeroScreen
import com.example.marvel.screens.MainScreen
import com.example.marvel.utils.Constants
import okhttp3.Route

sealed class Screens(val route: String) {
    object Main: Screens(route = Constants.Screens.MAIN_SCREEN)
    object Hero: Screens(route = Constants.Screens.HERO_SCREEN)
}

@Composable
fun SetupNavHost(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screens.Main.route
    ){
        composable(route = Screens.Main.route){
            MainScreen()

        }

        composable(route = Screens.Hero.route){
            HeroScreen()

        }

    }

}